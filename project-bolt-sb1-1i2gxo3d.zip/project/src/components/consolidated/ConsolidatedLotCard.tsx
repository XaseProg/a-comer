import React from 'react';
import { ConsolidatedLot, LogisticsQuote } from '../../types';
import { MapPin, Package, Clock, Truck, Users, DollarSign, Route } from 'lucide-react';

interface ConsolidatedLotCardProps {
  lot: ConsolidatedLot;
  onReserve?: (lotId: string, logisticsOption: 'beneficiary_covers' | 'shared_logistics') => void;
  onJoinShared?: (lotId: string) => void;
  showActions?: boolean;
  logisticsQuotes?: LogisticsQuote[];
}

const ConsolidatedLotCard: React.FC<ConsolidatedLotCardProps> = ({ 
  lot, 
  onReserve, 
  onJoinShared,
  showActions = true,
  logisticsQuotes = []
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'forming': return 'bg-yellow-100 text-yellow-800';
      case 'ready': return 'bg-green-100 text-green-800';
      case 'assigned': return 'bg-blue-100 text-blue-800';
      case 'in_collection': return 'bg-purple-100 text-purple-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'forming': return 'Formándose';
      case 'ready': return 'Listo para recolección';
      case 'assigned': return 'Asignado';
      case 'in_collection': return 'En recolección';
      case 'completed': return 'Completado';
      default: return status;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTimeUntilDeadline = () => {
    const now = new Date();
    const deadline = new Date(lot.collectionDeadline);
    const diffTime = deadline.getTime() - now.getTime();
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    if (diffHours <= 0) return 'Vencido';
    if (diffHours <= 24) return `${diffHours}h restantes`;
    return `${Math.ceil(diffHours / 24)} días restantes`;
  };

  const bestQuote = logisticsQuotes.length > 0 
    ? logisticsQuotes.reduce((best, current) => 
        current.totalCost < best.totalCost ? current : best
      )
    : null;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              Lote Consolidado - {lot.zone}
            </h3>
            <p className="text-sm text-gray-600">
              {lot.totalItems} alimentos • {lot.totalWeight} kg total
            </p>
          </div>
          <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(lot.status)}`}>
            {getStatusText(lot.status)}
          </span>
        </div>

        <div className="space-y-3 mb-4">
          <div className="flex items-center text-sm text-gray-600">
            <MapPin className="h-4 w-4 mr-2" />
            <span>Centro: {lot.centerCoordinates.lat.toFixed(4)}, {lot.centerCoordinates.lng.toFixed(4)}</span>
          </div>

          <div className="flex items-center text-sm text-gray-600">
            <Clock className="h-4 w-4 mr-2" />
            <span>Límite: {formatDate(lot.collectionDeadline)}</span>
            <span className={`ml-2 font-medium ${
              getTimeUntilDeadline().includes('Vencido') ? 'text-red-600' :
              getTimeUntilDeadline().includes('h restantes') ? 'text-orange-600' :
              'text-green-600'
            }`}>
              ({getTimeUntilDeadline()})
            </span>
          </div>

          <div className="flex items-center text-sm text-gray-600">
            <Route className="h-4 w-4 mr-2" />
            <span>{lot.optimizedRoute.length} puntos de recolección</span>
          </div>

          <div className="flex items-center text-sm text-gray-600">
            <DollarSign className="h-4 w-4 mr-2" />
            <span>Costo estimado: ${lot.estimatedLogisticsCost.toLocaleString()}</span>
            {bestQuote && (
              <span className="ml-2 text-green-600 font-medium">
                (Mejor oferta: ${bestQuote.totalCost.toLocaleString()})
              </span>
            )}
          </div>

          {lot.interestedBeneficiaries.length > 0 && (
            <div className="flex items-center text-sm text-gray-600">
              <Users className="h-4 w-4 mr-2" />
              <span>{lot.interestedBeneficiaries.length} organizaciones interesadas</span>
            </div>
          )}
        </div>

        {/* Ruta optimizada */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Ruta de Recolección:</h4>
          <div className="space-y-1">
            {lot.optimizedRoute.map((stop, index) => (
              <div key={index} className="flex items-center text-xs text-gray-600 bg-gray-50 p-2 rounded">
                <span className="w-6 h-6 bg-green-100 text-green-800 rounded-full flex items-center justify-center text-xs font-medium mr-2">
                  {index + 1}
                </span>
                <span className="flex-1 truncate">{stop.address}</span>
                <span className="text-gray-500">~{stop.estimatedTime}min</span>
              </div>
            ))}
          </div>
        </div>

        {showActions && lot.status === 'ready' && (
          <div className="space-y-2">
            <div className="flex space-x-2">
              {onReserve && (
                <>
                  <button
                    onClick={() => onReserve(lot.id, 'beneficiary_covers')}
                    className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-green-700 transition-colors"
                  >
                    <Truck className="h-4 w-4 inline mr-1" />
                    Reservar (Yo cubro logística)
                  </button>
                  <button
                    onClick={() => onReserve(lot.id, 'shared_logistics')}
                    className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
                  >
                    <Users className="h-4 w-4 inline mr-1" />
                    Logística compartida
                  </button>
                </>
              )}
            </div>
            
            {lot.logisticsOption === 'shared_logistics' && onJoinShared && (
              <button
                onClick={() => onJoinShared(lot.id)}
                className="w-full bg-purple-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-purple-700 transition-colors"
              >
                <Users className="h-4 w-4 inline mr-1" />
                Unirse a logística compartida
              </button>
            )}
          </div>
        )}

        {lot.status === 'assigned' && (
          <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
            <p className="text-sm text-blue-800">
              <strong>Lote asignado</strong> - La recolección está programada
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ConsolidatedLotCard;