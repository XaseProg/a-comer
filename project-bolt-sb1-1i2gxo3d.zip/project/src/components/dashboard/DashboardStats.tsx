import React from 'react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import { Package, Users, Truck, Leaf, TrendingUp, Calendar } from 'lucide-react';

const DashboardStats: React.FC = () => {
  const { stats, foodItems, donations } = useData();
  const { user } = useAuth();

  const getPersonalizedStats = () => {
    switch (user?.role) {
      case 'donor':
        const myDonations = foodItems.filter(item => item.donorId === user.id);
        const myDeliveredDonations = myDonations.filter(item => item.status === 'delivered');
        return [
          {
            title: 'Mis Donaciones',
            value: myDonations.length,
            icon: Package,
            color: 'bg-blue-500',
            description: 'Alimentos publicados'
          },
          {
            title: 'Entregados',
            value: myDeliveredDonations.length,
            icon: TrendingUp,
            color: 'bg-green-500',
            description: 'Donaciones completadas'
          },
          {
            title: 'Disponibles',
            value: myDonations.filter(item => item.status === 'available').length,
            icon: Calendar,
            color: 'bg-yellow-500',
            description: 'Esperando receptor'
          },
          {
            title: 'En Proceso',
            value: myDonations.filter(item => ['reserved', 'in_transit'].includes(item.status)).length,
            icon: Truck,
            color: 'bg-purple-500',
            description: 'En camino'
          }
        ];

      case 'receiver':
        const myReservations = foodItems.filter(item => item.reservedBy === user.id);
        const myReceivedDonations = myReservations.filter(item => item.status === 'delivered');
        return [
          {
            title: 'Mis Reservas',
            value: myReservations.length,
            icon: Package,
            color: 'bg-blue-500',
            description: 'Alimentos reservados'
          },
          {
            title: 'Recibidos',
            value: myReceivedDonations.length,
            icon: TrendingUp,
            color: 'bg-green-500',
            description: 'Donaciones recibidas'
          },
          {
            title: 'Disponibles',
            value: foodItems.filter(item => item.status === 'available').length,
            icon: Calendar,
            color: 'bg-yellow-500',
            description: 'Para reservar'
          },
          {
            title: 'Personas Atendidas',
            value: user.capacity || 0,
            icon: Users,
            color: 'bg-purple-500',
            description: 'Capacidad diaria'
          }
        ];

      case 'volunteer':
        const myDeliveries = donations.filter(donation => donation.volunteerId === user.id);
        const completedDeliveries = myDeliveries.filter(donation => donation.status === 'delivered');
        return [
          {
            title: 'Mis Entregas',
            value: myDeliveries.length,
            icon: Truck,
            color: 'bg-blue-500',
            description: 'Entregas asignadas'
          },
          {
            title: 'Completadas',
            value: completedDeliveries.length,
            icon: TrendingUp,
            color: 'bg-green-500',
            description: 'Entregas realizadas'
          },
          {
            title: 'Disponibles',
            value: donations.filter(d => !d.volunteerId && d.status === 'confirmed').length,
            icon: Calendar,
            color: 'bg-yellow-500',
            description: 'Para tomar'
          },
          {
            title: 'En Proceso',
            value: myDeliveries.filter(d => d.status === 'in_transit').length,
            icon: Package,
            color: 'bg-purple-500',
            description: 'En camino'
          }
        ];

      default:
        return [
          {
            title: 'Total Rescatado',
            value: `${stats.totalKgRescued} kg`,
            icon: Package,
            color: 'bg-blue-500',
            description: 'Alimentos salvados'
          },
          {
            title: 'Donaciones',
            value: stats.totalDonations,
            icon: TrendingUp,
            color: 'bg-green-500',
            description: 'Entregas completadas'
          },
          {
            title: 'Usuarios Activos',
            value: stats.activeDonors + stats.activeReceivers + stats.activeVolunteers,
            icon: Users,
            color: 'bg-yellow-500',
            description: 'En la plataforma'
          },
          {
            title: 'CO₂ Ahorrado',
            value: `${stats.co2Saved} kg`,
            icon: Leaf,
            color: 'bg-purple-500',
            description: 'Impacto ambiental'
          }
        ];
    }
  };

  const statsData = getPersonalizedStats();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statsData.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className={`${stat.color} rounded-lg p-3`}>
                <Icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.description}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DashboardStats;