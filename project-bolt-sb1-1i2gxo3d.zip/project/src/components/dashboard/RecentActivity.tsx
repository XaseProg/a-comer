import React from 'react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import { Clock, Package, CheckCircle, Truck, AlertCircle } from 'lucide-react';

const RecentActivity: React.FC = () => {
  const { foodItems, donations } = useData();
  const { user } = useAuth();

  const getRecentActivity = () => {
    const activities: Array<{
      id: string;
      type: 'donation_created' | 'donation_reserved' | 'donation_delivered' | 'food_added';
      title: string;
      description: string;
      time: string;
      icon: any;
      color: string;
    }> = [];

    // Actividades basadas en el rol del usuario
    if (user?.role === 'donor') {
      const myItems = foodItems.filter(item => item.donorId === user.id);
      
      myItems.forEach(item => {
        if (item.status === 'delivered') {
          activities.push({
            id: `delivered-${item.id}`,
            type: 'donation_delivered',
            title: 'Donación entregada',
            description: `${item.name} fue entregado exitosamente`,
            time: item.updatedAt,
            icon: CheckCircle,
            color: 'text-green-600'
          });
        } else if (item.status === 'reserved') {
          activities.push({
            id: `reserved-${item.id}`,
            type: 'donation_reserved',
            title: 'Donación reservada',
            description: `${item.name} fue reservado por una organización`,
            time: item.updatedAt,
            icon: Package,
            color: 'text-blue-600'
          });
        } else if (item.status === 'available') {
          activities.push({
            id: `created-${item.id}`,
            type: 'food_added',
            title: 'Alimento publicado',
            description: `${item.name} está disponible para donación`,
            time: item.createdAt,
            icon: Package,
            color: 'text-gray-600'
          });
        }
      });
    }

    if (user?.role === 'receiver') {
      const myReservations = foodItems.filter(item => item.reservedBy === user.id);
      
      myReservations.forEach(item => {
        if (item.status === 'delivered') {
          activities.push({
            id: `received-${item.id}`,
            type: 'donation_delivered',
            title: 'Donación recibida',
            description: `Recibiste ${item.name} de ${item.donorName}`,
            time: item.updatedAt,
            icon: CheckCircle,
            color: 'text-green-600'
          });
        } else {
          activities.push({
            id: `reserved-${item.id}`,
            type: 'donation_reserved',
            title: 'Donación reservada',
            description: `Reservaste ${item.name} de ${item.donorName}`,
            time: item.updatedAt,
            icon: Package,
            color: 'text-blue-600'
          });
        }
      });
    }

    if (user?.role === 'volunteer') {
      const myDeliveries = donations.filter(donation => donation.volunteerId === user.id);
      
      myDeliveries.forEach(donation => {
        const item = foodItems.find(f => f.id === donation.foodItemId);
        if (item) {
          if (donation.status === 'delivered') {
            activities.push({
              id: `delivered-${donation.id}`,
              type: 'donation_delivered',
              title: 'Entrega completada',
              description: `Entregaste ${item.name} exitosamente`,
              time: donation.updatedAt,
              icon: CheckCircle,
              color: 'text-green-600'
            });
          } else if (donation.status === 'in_transit') {
            activities.push({
              id: `transit-${donation.id}`,
              type: 'donation_reserved',
              title: 'En camino',
              description: `Transportando ${item.name}`,
              time: donation.updatedAt,
              icon: Truck,
              color: 'text-yellow-600'
            });
          }
        }
      });
    }

    // Ordenar por fecha más reciente
    return activities
      .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())
      .slice(0, 5);
  };

  const activities = getRecentActivity();

  const formatTime = (timeString: string) => {
    const time = new Date(timeString);
    const now = new Date();
    const diffInHours = (now.getTime() - time.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'Hace unos minutos';
    } else if (diffInHours < 24) {
      return `Hace ${Math.floor(diffInHours)} horas`;
    } else {
      return `Hace ${Math.floor(diffInHours / 24)} días`;
    }
  };

  if (activities.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Actividad Reciente</h3>
        <div className="text-center py-8">
          <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No hay actividad reciente</p>
          <p className="text-sm text-gray-400 mt-2">
            {user?.role === 'donor' && 'Publica tu primer alimento para comenzar'}
            {user?.role === 'receiver' && 'Reserva alimentos disponibles para comenzar'}
            {user?.role === 'volunteer' && 'Toma tu primera entrega para comenzar'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Actividad Reciente</h3>
      <div className="space-y-4">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <div key={activity.id} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 ${activity.color}`}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">
                  {activity.title}
                </p>
                <p className="text-sm text-gray-500">
                  {activity.description}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {formatTime(activity.time)}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RecentActivity;