import React, { useState } from 'react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import { Package, Calendar, FileText, Hash, Tag } from 'lucide-react';

const AddFoodForm: React.FC = () => {
  const { addFoodItem } = useData();
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    quantity: '',
    unit: 'kg',
    category: 'other' as const,
    expirationDate: '',
    collectionDeadline: '',
    availableHoursStart: '08:00',
    availableHoursEnd: '18:00',
    refrigerationRequired: false,
    fragile: false,
    heavyItem: false,
    specialNotes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const categories = [
    { value: 'fruits', label: 'Frutas' },
    { value: 'vegetables', label: 'Verduras' },
    { value: 'dairy', label: 'Lácteos' },
    { value: 'meat', label: 'Carnes' },
    { value: 'bakery', label: 'Panadería' },
    { value: 'canned', label: 'Enlatados' },
    { value: 'other', label: 'Otros' }
  ];

  const units = [
    { value: 'kg', label: 'Kilogramos' },
    { value: 'unidades', label: 'Unidades' },
    { value: 'litros', label: 'Litros' },
    { value: 'paquetes', label: 'Paquetes' },
    { value: 'cajas', label: 'Cajas' }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSubmitting(true);
    
    // Simular delay de envío
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newFoodItem = {
      donorId: user.id,
      donorName: user.businessName || user.name,
      donorAddress: user.address,
      donorCoordinates: user.coordinates || { lat: -34.6037, lng: -58.3816 },
      name: formData.name,
      description: formData.description,
      quantity: parseInt(formData.quantity),
      unit: formData.unit,
      category: formData.category,
      expirationDate: formData.expirationDate,
      collectionDeadline: formData.collectionDeadline,
      availableHours: {
        start: formData.availableHoursStart,
        end: formData.availableHoursEnd
      },
      specialConditions: {
        refrigerationRequired: formData.refrigerationRequired,
        fragile: formData.fragile,
        heavyItem: formData.heavyItem,
        notes: formData.specialNotes
      },
      status: 'available' as const
    };

    addFoodItem(newFoodItem);
    
    setSuccess(true);
    setFormData({
      name: '',
      description: '',
      quantity: '',
      unit: 'kg',
      category: 'other',
      expirationDate: '',
      collectionDeadline: '',
      availableHoursStart: '08:00',
      availableHoursEnd: '18:00',
      refrigerationRequired: false,
      fragile: false,
      heavyItem: false,
      specialNotes: ''
    });
    
    setIsSubmitting(false);
    
    // Ocultar mensaje de éxito después de 3 segundos
    setTimeout(() => setSuccess(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  // Calcular fecha mínima (hoy)
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Agregar Alimento para Donación
          </h2>
          <p className="text-gray-600">
            Completa la información del alimento que deseas donar
          </p>
        </div>

        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-md">
            <p className="text-green-800 font-medium">
              ¡Alimento agregado exitosamente! Ya está disponible para reservar.
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
              Nombre del alimento *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Package className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                id="name"
                name="name"
                required
                value={formData.name}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
                placeholder="Ej: Pan integral, Verduras frescas"
              />
            </div>
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
              Descripción
            </label>
            <div className="relative">
              <div className="absolute top-3 left-3 pointer-events-none">
                <FileText className="h-5 w-5 text-gray-400" />
              </div>
              <textarea
                id="description"
                name="description"
                rows={3}
                value={formData.description}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
                placeholder="Describe el estado, características especiales, etc."
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-2">
                Cantidad *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Hash className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="number"
                  id="quantity"
                  name="quantity"
                  required
                  min="1"
                  value={formData.quantity}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
                  placeholder="0"
                />
              </div>
            </div>

            <div>
              <label htmlFor="unit" className="block text-sm font-medium text-gray-700 mb-2">
                Unidad *
              </label>
              <select
                id="unit"
                name="unit"
                required
                value={formData.unit}
                onChange={handleChange}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              >
                {units.map(unit => (
                  <option key={unit.value} value={unit.value}>
                    {unit.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
              Categoría *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Tag className="h-5 w-5 text-gray-400" />
              </div>
              <select
                id="category"
                name="category"
                required
                value={formData.category}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              >
                {categories.map(category => (
                  <option key={category.value} value={category.value}>
                    {category.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="expirationDate" className="block text-sm font-medium text-gray-700 mb-2">
              Fecha de vencimiento *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="date"
                id="expirationDate"
                name="expirationDate"
                required
                min={today}
                value={formData.expirationDate}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>
          </div>

          <div>
            <label htmlFor="collectionDeadline" className="block text-sm font-medium text-gray-700 mb-2">
              Fecha límite de recolección *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="date"
                id="collectionDeadline"
                name="collectionDeadline"
                required
                min={today}
                value={formData.collectionDeadline}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Fecha límite para que recojan el alimento
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Horarios de retiro disponibles
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="availableHoursStart" className="block text-xs text-gray-600 mb-1">
                  Desde
                </label>
                <input
                  type="time"
                  id="availableHoursStart"
                  name="availableHoursStart"
                  value={formData.availableHoursStart}
                  onChange={handleChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                />
              </div>
              <div>
                <label htmlFor="availableHoursEnd" className="block text-xs text-gray-600 mb-1">
                  Hasta
                </label>
                <input
                  type="time"
                  id="availableHoursEnd"
                  name="availableHoursEnd"
                  value={formData.availableHoursEnd}
                  onChange={handleChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Condiciones especiales
            </label>
            <div className="space-y-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="refrigerationRequired"
                  checked={formData.refrigerationRequired}
                  onChange={(e) => setFormData(prev => ({ ...prev, refrigerationRequired: e.target.checked }))}
                  className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Requiere refrigeración</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="fragile"
                  checked={formData.fragile}
                  onChange={(e) => setFormData(prev => ({ ...prev, fragile: e.target.checked }))}
                  className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Frágil (manejar con cuidado)</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="heavyItem"
                  checked={formData.heavyItem}
                  onChange={(e) => setFormData(prev => ({ ...prev, heavyItem: e.target.checked }))}
                  className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Artículo pesado</span>
              </label>
            </div>
          </div>

          <div>
            <label htmlFor="specialNotes" className="block text-sm font-medium text-gray-700 mb-2">
              Notas especiales
            </label>
            <textarea
              id="specialNotes"
              name="specialNotes"
              rows={2}
              value={formData.specialNotes}
              onChange={handleChange}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
              placeholder="Instrucciones adicionales para la recolección..."
            />
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => setFormData({
                name: '',
                description: '',
                quantity: '',
                unit: 'kg',
                category: 'other',
                expirationDate: '',
                collectionDeadline: '',
                availableHoursStart: '08:00',
                availableHoursEnd: '18:00',
                refrigerationRequired: false,
                fragile: false,
                heavyItem: false,
                specialNotes: ''
              })}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Limpiar
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Agregando...' : 'Agregar Alimento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddFoodForm;