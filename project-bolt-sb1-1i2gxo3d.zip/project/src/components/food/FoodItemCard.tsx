import React from 'react';
import { FoodItem } from '../../types';
import { Calendar, MapPin, Package, AlertTriangle, Clock, User } from 'lucide-react';

interface FoodItemCardProps {
  item: FoodItem;
  onReserve?: (itemId: string) => void;
  onEdit?: (itemId: string) => void;
  showActions?: boolean;
  userRole?: string;
}

const FoodItemCard: React.FC<FoodItemCardProps> = ({ 
  item, 
  onReserve, 
  onEdit, 
  showActions = true,
  userRole 
}) => {
  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-800';
      case 'reserved': return 'bg-blue-100 text-blue-800';
      case 'in_transit': return 'bg-yellow-100 text-yellow-800';
      case 'delivered': return 'bg-gray-100 text-gray-800';
      case 'expired': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'Disponible';
      case 'reserved': return 'Reservado';
      case 'in_transit': return 'En camino';
      case 'delivered': return 'Entregado';
      case 'expired': return 'Vencido';
      default: return status;
    }
  };

  const getUrgencyText = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'Urgente';
      case 'medium': return 'Moderado';
      case 'low': return 'Sin prisa';
      default: return urgency;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getDaysUntilExpiry = () => {
    const now = new Date();
    const expiry = new Date(item.expirationDate);
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysUntilExpiry = getDaysUntilExpiry();

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
      {item.imageUrl && (
        <div className="h-48 bg-gray-200">
          <img 
            src={item.imageUrl} 
            alt={item.name}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-lg font-semibold text-gray-900 flex-1">
            {item.name}
          </h3>
          <div className="flex space-x-2 ml-2">
            <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getUrgencyColor(item.urgency)}`}>
              {getUrgencyText(item.urgency)}
            </span>
            <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(item.status)}`}>
              {getStatusText(item.status)}
            </span>
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {item.description}
        </p>

        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-gray-500">
            <Package className="h-4 w-4 mr-2" />
            <span>{item.quantity} {item.unit}</span>
          </div>

          <div className="flex items-center text-sm text-gray-500">
            <Calendar className="h-4 w-4 mr-2" />
            <span>Vence: {formatDate(item.expirationDate)}</span>
            {daysUntilExpiry <= 2 && (
              <AlertTriangle className="h-4 w-4 ml-2 text-red-500" />
            )}
          </div>

          <div className="flex items-center text-sm text-gray-500">
            <User className="h-4 w-4 mr-2" />
            <span>{item.donorName}</span>
          </div>

          <div className="flex items-center text-sm text-gray-500">
            <MapPin className="h-4 w-4 mr-2" />
            <span className="truncate">{item.donorAddress}</span>
          </div>

          {item.collectionDeadline && (
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="h-4 w-4 mr-2" />
              <span>Límite recolección: {formatDate(item.collectionDeadline)}</span>
            </div>
          )}

          {item.availableHours && (
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="h-4 w-4 mr-2" />
              <span>Horario: {item.availableHours.start} - {item.availableHours.end}</span>
            </div>
          )}

          {item.specialConditions && (
            <div className="flex flex-wrap gap-1 mt-2">
              {item.specialConditions.refrigerationRequired && (
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                  Refrigeración
                </span>
              )}
              {item.specialConditions.fragile && (
                <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                  Frágil
                </span>
              )}
              {item.specialConditions.heavyItem && (
                <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">
                  Pesado
                </span>
              )}
            </div>
          )}

          {item.consolidatedLotId && (
            <div className="flex items-center text-sm text-purple-600 bg-purple-50 px-2 py-1 rounded">
              <Package className="h-4 w-4 mr-1" />
              <span>Parte del lote: {item.consolidatedLotId}</span>
            </div>
          )}

          {daysUntilExpiry >= 0 && (
            <div className="flex items-center text-sm">
              <Clock className="h-4 w-4 mr-2" />
              <span className={daysUntilExpiry <= 1 ? 'text-red-600 font-medium' : 'text-gray-500'}>
                {daysUntilExpiry === 0 ? 'Vence hoy' : 
                 daysUntilExpiry === 1 ? 'Vence mañana' : 
                 `${daysUntilExpiry} días para vencer`}
              </span>
            </div>
          )}
        </div>

        {showActions && (
          <div className="flex space-x-2">
            {userRole === 'receiver' && item.status === 'available' && onReserve && (
              <button
                onClick={() => onReserve(item.id)}
                className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-green-700 transition-colors"
              >
                Reservar
              </button>
            )}
            
            {userRole === 'donor' && onEdit && (
              <button
                onClick={() => onEdit(item.id)}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
              >
                Editar
              </button>
            )}

            {item.status === 'available' && userRole !== 'donor' && userRole !== 'receiver' && (
              <div className="flex-1 text-center py-2 text-sm text-gray-500">
                Disponible para reservar
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default FoodItemCard;