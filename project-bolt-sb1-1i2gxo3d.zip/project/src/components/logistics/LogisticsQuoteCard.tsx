import React from 'react';
import { LogisticsQuote, LogisticsProvider } from '../../types';
import { Truck, Clock, Star, CheckCircle } from 'lucide-react';

interface LogisticsQuoteCardProps {
  quote: LogisticsQuote;
  provider: LogisticsProvider;
  onSelect?: (quoteId: string) => void;
  isSelected?: boolean;
}

const LogisticsQuoteCard: React.FC<LogisticsQuoteCardProps> = ({ 
  quote, 
  provider, 
  onSelect,
  isSelected = false 
}) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}min` : `${mins}min`;
  };

  const getRatingStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating) 
            ? 'text-yellow-400 fill-current' 
            : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className={`bg-white rounded-lg border-2 p-4 transition-all ${
      isSelected 
        ? 'border-green-500 shadow-md' 
        : 'border-gray-200 hover:border-gray-300'
    }`}>
      <div className="flex items-start justify-between mb-3">
        <div>
          <h4 className="font-semibold text-gray-900">{provider.name}</h4>
          <div className="flex items-center mt-1">
            <div className="flex">{getRatingStars(provider.rating)}</div>
            <span className="ml-2 text-sm text-gray-600">
              {provider.rating.toFixed(1)}
            </span>
          </div>
        </div>
        {isSelected && (
          <CheckCircle className="h-6 w-6 text-green-500" />
        )}
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Costo total:</span>
          <span className="font-bold text-lg text-green-600">
            {formatCurrency(quote.totalCost)}
          </span>
        </div>

        <div className="flex items-center text-sm text-gray-600">
          <Truck className="h-4 w-4 mr-2" />
          <span>{quote.vehicleType}</span>
        </div>

        <div className="flex items-center text-sm text-gray-600">
          <Clock className="h-4 w-4 mr-2" />
          <span>Tiempo estimado: {formatTime(quote.estimatedTime)}</span>
        </div>
      </div>

      {quote.specialServices.length > 0 && (
        <div className="mb-4">
          <p className="text-xs font-medium text-gray-700 mb-2">Servicios especiales:</p>
          <div className="flex flex-wrap gap-1">
            {quote.specialServices.map((service, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
              >
                {service === 'refrigerated' && 'Refrigerado'}
                {service === 'fragileItems' && 'Frágiles'}
                {service === 'heavyLifting' && 'Carga pesada'}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="text-xs text-gray-500 mb-3">
        Válido hasta: {new Date(quote.validUntil).toLocaleDateString('es-AR')}
      </div>

      {onSelect && (
        <button
          onClick={() => onSelect(quote.id)}
          className={`w-full py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            isSelected
              ? 'bg-green-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {isSelected ? 'Seleccionado' : 'Seleccionar'}
        </button>
      )}
    </div>
  );
};

export default LogisticsQuoteCard;