import React from 'react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import DashboardStats from '../dashboard/DashboardStats';
import RecentActivity from '../dashboard/RecentActivity';
import FoodItemCard from '../food/FoodItemCard';
import { Plus, Package } from 'lucide-react';

interface DonorDashboardProps {
  onPageChange: (page: string) => void;
}

const DonorDashboard: React.FC<DonorDashboardProps> = ({ onPageChange }) => {
  const { getFoodItemsByDonor } = useData();
  const { user } = useAuth();
  
  const myFoodItems = user ? getFoodItemsByDonor(user.id) : [];
  const recentItems = myFoodItems.slice(0, 3);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Bienvenido, {user?.businessName || user?.name}
          </h1>
          <p className="mt-2 text-gray-600">
            Gestiona tus donaciones y ayuda a reducir el desperdicio de alimentos
          </p>
        </div>
        <button
          onClick={() => onPageChange('add-food')}
          className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <Plus className="h-4 w-4 mr-2" />
          Agregar Alimento
        </button>
      </div>

      {/* Stats */}
      <DashboardStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <RecentActivity />
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Acciones Rápidas</h3>
          <div className="space-y-3">
            <button
              onClick={() => onPageChange('add-food')}
              className="w-full flex items-center justify-center px-4 py-3 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-2" />
              Agregar Alimento
            </button>
            <button
              onClick={() => onPageChange('donations')}
              className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
            >
              <Package className="h-4 w-4 mr-2" />
              Ver Mis Donaciones
            </button>
          </div>
        </div>
      </div>

      {/* Recent Food Items */}
      {recentItems.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">
              Alimentos Recientes
            </h2>
            <button
              onClick={() => onPageChange('donations')}
              className="text-green-600 hover:text-green-700 text-sm font-medium"
            >
              Ver todos →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentItems.map(item => (
              <FoodItemCard
                key={item.id}
                item={item}
                userRole="donor"
                showActions={false}
              />
            ))}
          </div>
        </div>
      )}

      {myFoodItems.length === 0 && (
        <div className="text-center py-12">
          <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No tienes alimentos publicados
          </h3>
          <p className="text-gray-500 mb-6">
            Comienza agregando tu primer alimento para donación
          </p>
          <button
            onClick={() => onPageChange('add-food')}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Agregar Primer Alimento
          </button>
        </div>
      )}
    </div>
  );
};

export default DonorDashboard;