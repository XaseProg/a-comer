import React from 'react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import DashboardStats from '../dashboard/DashboardStats';
import RecentActivity from '../dashboard/RecentActivity';
import FoodItemCard from '../food/FoodItemCard';
import { Search, Package, Heart } from 'lucide-react';

interface ReceiverDashboardProps {
  onPageChange: (page: string) => void;
}

const ReceiverDashboard: React.FC<ReceiverDashboardProps> = ({ onPageChange }) => {
  const { getAvailableFoodItems, getFoodItemsByReceiver, reserveFoodItem } = useData();
  const { user } = useAuth();
  
  const availableItems = getAvailableFoodItems().slice(0, 3);
  const myReservations = user ? getFoodItemsByReceiver(user.id).slice(0, 3) : [];

  const handleReserve = (itemId: string) => {
    if (user) {
      reserveFoodItem(itemId, user.id);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Bienvenido, {user?.name}
          </h1>
          <p className="mt-2 text-gray-600">
            Encuentra alimentos disponibles para tu organización
          </p>
        </div>
        <button
          onClick={() => onPageChange('available-food')}
          className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <Search className="h-4 w-4 mr-2" />
          Buscar Alimentos
        </button>
      </div>

      {/* Stats */}
      <DashboardStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <RecentActivity />
        </div>

        {/* Organization Info */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Tu Organización</h3>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Tipo</p>
              <p className="font-medium">{user?.organizationType || 'No especificado'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Capacidad</p>
              <p className="font-medium">{user?.capacity || 0} personas</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Ubicación</p>
              <p className="font-medium text-sm">{user?.address}</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <button
              onClick={() => onPageChange('available-food')}
              className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 transition-colors"
            >
              <Search className="h-4 w-4 mr-2" />
              Buscar Alimentos
            </button>
          </div>
        </div>
      </div>

      {/* Available Food Items */}
      {availableItems.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">
              Alimentos Disponibles
            </h2>
            <button
              onClick={() => onPageChange('available-food')}
              className="text-green-600 hover:text-green-700 text-sm font-medium"
            >
              Ver todos →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableItems.map(item => (
              <FoodItemCard
                key={item.id}
                item={item}
                userRole="receiver"
                onReserve={handleReserve}
              />
            ))}
          </div>
        </div>
      )}

      {/* My Reservations */}
      {myReservations.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">
              Mis Reservas Recientes
            </h2>
            <button
              onClick={() => onPageChange('my-reservations')}
              className="text-green-600 hover:text-green-700 text-sm font-medium"
            >
              Ver todas →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myReservations.map(item => (
              <FoodItemCard
                key={item.id}
                item={item}
                userRole="receiver"
                showActions={false}
              />
            ))}
          </div>
        </div>
      )}

      {availableItems.length === 0 && myReservations.length === 0 && (
        <div className="text-center py-12">
          <Heart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No hay alimentos disponibles en este momento
          </h3>
          <p className="text-gray-500 mb-6">
            Te notificaremos cuando haya nuevas donaciones disponibles
          </p>
          <button
            onClick={() => onPageChange('available-food')}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
          >
            <Search className="h-4 w-4 mr-2" />
            Buscar Alimentos
          </button>
        </div>
      )}
    </div>
  );
};

export default ReceiverDashboard;