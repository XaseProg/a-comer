import React from 'react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';
import DashboardStats from '../dashboard/DashboardStats';
import RecentActivity from '../dashboard/RecentActivity';
import { Truck, MapPin, Clock, Package } from 'lucide-react';

interface VolunteerDashboardProps {
  onPageChange: (page: string) => void;
}

const VolunteerDashboard: React.FC<VolunteerDashboardProps> = ({ onPageChange }) => {
  const { donations, foodItems, assignVolunteer } = useData();
  const { user } = useAuth();
  
  const myDeliveries = donations.filter(donation => donation.volunteerId === user?.id);
  const availableDeliveries = donations.filter(donation => 
    !donation.volunteerId && donation.status === 'confirmed'
  ).slice(0, 3);

  const handleTakeDelivery = (donationId: string) => {
    if (user) {
      assignVolunteer(donationId, user.id);
    }
  };

  const getDeliveryInfo = (donation: any) => {
    const item = foodItems.find(f => f.id === donation.foodItemId);
    return {
      item,
      donation
    };
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Bienvenido, {user?.name}
          </h1>
          <p className="mt-2 text-gray-600">
            Ayuda a conectar donantes con quienes más lo necesitan
          </p>
        </div>
        <button
          onClick={() => onPageChange('available-deliveries')}
          className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <Truck className="h-4 w-4 mr-2" />
          Ver Entregas Disponibles
        </button>
      </div>

      {/* Stats */}
      <DashboardStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <RecentActivity />
        </div>

        {/* Volunteer Info */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Tu Perfil</h3>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Vehículo</p>
              <p className="font-medium">{user?.vehicleType || 'No especificado'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Ubicación</p>
              <p className="font-medium text-sm">{user?.address}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Estado</p>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                Activo
              </span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <button
              onClick={() => onPageChange('available-deliveries')}
              className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 transition-colors"
            >
              <Truck className="h-4 w-4 mr-2" />
              Buscar Entregas
            </button>
          </div>
        </div>
      </div>

      {/* Available Deliveries */}
      {availableDeliveries.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">
              Entregas Disponibles
            </h2>
            <button
              onClick={() => onPageChange('available-deliveries')}
              className="text-green-600 hover:text-green-700 text-sm font-medium"
            >
              Ver todas →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableDeliveries.map(delivery => {
              const { item } = getDeliveryInfo(delivery);
              if (!item) return null;

              return (
                <div key={delivery.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {item.name}
                    </h3>
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                      Disponible
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <Package className="h-4 w-4 mr-2" />
                      <span>{item.quantity} {item.unit}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span className="truncate">Desde: {item.donorAddress}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Clock className="h-4 w-4 mr-2" />
                      <span>Vence: {new Date(item.expirationDate).toLocaleDateString('es-AR')}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleTakeDelivery(delivery.id)}
                    className="w-full bg-green-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-green-700 transition-colors"
                  >
                    Tomar Entrega
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* My Active Deliveries */}
      {myDeliveries.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">
              Mis Entregas Activas
            </h2>
            <button
              onClick={() => onPageChange('routes')}
              className="text-green-600 hover:text-green-700 text-sm font-medium"
            >
              Ver todas →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myDeliveries.slice(0, 3).map(delivery => {
              const { item } = getDeliveryInfo(delivery);
              if (!item) return null;

              const getStatusColor = (status: string) => {
                switch (status) {
                  case 'confirmed': return 'bg-blue-100 text-blue-800';
                  case 'in_transit': return 'bg-yellow-100 text-yellow-800';
                  case 'delivered': return 'bg-green-100 text-green-800';
                  default: return 'bg-gray-100 text-gray-800';
                }
              };

              const getStatusText = (status: string) => {
                switch (status) {
                  case 'confirmed': return 'Confirmado';
                  case 'in_transit': return 'En camino';
                  case 'delivered': return 'Entregado';
                  default: return status;
                }
              };

              return (
                <div key={delivery.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {item.name}
                    </h3>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(delivery.status)}`}>
                      {getStatusText(delivery.status)}
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <Package className="h-4 w-4 mr-2" />
                      <span>{item.quantity} {item.unit}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span className="truncate">Desde: {item.donorAddress}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => onPageChange('routes')}
                    className="w-full bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
                  >
                    Ver Detalles
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {availableDeliveries.length === 0 && myDeliveries.length === 0 && (
        <div className="text-center py-12">
          <Truck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No hay entregas disponibles en este momento
          </h3>
          <p className="text-gray-500 mb-6">
            Te notificaremos cuando haya nuevas entregas que necesiten voluntarios
          </p>
          <button
            onClick={() => onPageChange('available-deliveries')}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
          >
            <Truck className="h-4 w-4 mr-2" />
            Buscar Entregas
          </button>
        </div>
      )}
    </div>
  );
};

export default VolunteerDashboard;