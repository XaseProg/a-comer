import React from 'react';
import { TaxCertificate } from '../../types';
import { FileText, Download, Calendar, DollarSign, CheckCircle } from 'lucide-react';

interface TaxCertificateCardProps {
  certificate: TaxCertificate;
  onDownload?: (certificateId: string) => void;
}

const TaxCertificateCard: React.FC<TaxCertificateCardProps> = ({ 
  certificate, 
  onDownload 
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'issued': return 'bg-green-100 text-green-800';
      case 'sent': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendiente';
      case 'issued': return 'Emitido';
      case 'sent': return 'Enviado';
      default: return status;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center">
          <div className="bg-green-100 rounded-lg p-3 mr-4">
            <FileText className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              Certificado Fiscal {certificate.fiscalYear}
            </h3>
            <p className="text-sm text-gray-600">
              N° {certificate.certificateNumber}
            </p>
          </div>
        </div>
        <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(certificate.status)}`}>
          {getStatusText(certificate.status)}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="space-y-3">
          <div className="flex items-center text-sm">
            <Calendar className="h-4 w-4 mr-2 text-gray-400" />
            <span className="text-gray-600">Fecha de emisión:</span>
            <span className="ml-2 font-medium">{formatDate(certificate.issueDate)}</span>
          </div>

          <div className="flex items-center text-sm">
            <DollarSign className="h-4 w-4 mr-2 text-gray-400" />
            <span className="text-gray-600">Valor total donado:</span>
            <span className="ml-2 font-medium">{formatCurrency(certificate.totalValue)}</span>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center text-sm">
            <CheckCircle className="h-4 w-4 mr-2 text-gray-400" />
            <span className="text-gray-600">Donaciones incluidas:</span>
            <span className="ml-2 font-medium">{certificate.donationIds.length}</span>
          </div>

          <div className="flex items-center text-sm">
            <DollarSign className="h-4 w-4 mr-2 text-green-500" />
            <span className="text-gray-600">Deducción fiscal:</span>
            <span className="ml-2 font-bold text-green-600">
              {formatCurrency(certificate.taxDeductionAmount)}
            </span>
          </div>
        </div>
      </div>

      <div className="bg-green-50 border border-green-200 rounded-md p-3 mb-4">
        <p className="text-sm text-green-800">
          <strong>Beneficio fiscal:</strong> Puedes deducir hasta el 35% del valor donado 
          ({formatCurrency(certificate.taxDeductionAmount)}) en tu declaración de impuestos.
        </p>
      </div>

      {certificate.status === 'issued' && onDownload && (
        <div className="flex justify-end">
          <button
            onClick={() => onDownload(certificate.id)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 transition-colors"
          >
            <Download className="h-4 w-4 mr-2" />
            Descargar PDF
          </button>
        </div>
      )}

      {certificate.status === 'pending' && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3">
          <p className="text-sm text-yellow-800">
            El certificado está siendo procesado. Te notificaremos cuando esté listo.
          </p>
        </div>
      )}
    </div>
  );
};

export default TaxCertificateCard;