import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: Partial<User> & { password: string }) => Promise<boolean>;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => Promise<boolean>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simular carga inicial del usuario desde localStorage
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Simular autenticación
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Usuario demo para testing
    if (email === 'donor@test.com' && password === 'password') {
      const demoUser: User = {
        id: '1',
        email: 'donor@test.com',
        name: 'Supermercado Central',
        phone: '+54 11 1234-5678',
        role: 'donor',
        address: 'Av. Corrientes 1234, CABA',
        businessName: 'Supermercado Central',
        cuit: '20-12345678-9',
        isActive: true,
        createdAt: new Date().toISOString(),
        coordinates: { lat: -34.6037, lng: -58.3816 }
      };
      setUser(demoUser);
      localStorage.setItem('user', JSON.stringify(demoUser));
      setIsLoading(false);
      return true;
    }
    
    if (email === 'receiver@test.com' && password === 'password') {
      const demoUser: User = {
        id: '2',
        email: 'receiver@test.com',
        name: 'Comedor Los Pibes',
        phone: '+54 11 8765-4321',
        role: 'receiver',
        address: 'San Martín 567, CABA',
        organizationType: 'Comedor comunitario',
        capacity: 200,
        isActive: true,
        createdAt: new Date().toISOString(),
        coordinates: { lat: -34.6118, lng: -58.3960 }
      };
      setUser(demoUser);
      localStorage.setItem('user', JSON.stringify(demoUser));
      setIsLoading(false);
      return true;
    }

    if (email === 'volunteer@test.com' && password === 'password') {
      const demoUser: User = {
        id: '3',
        email: 'volunteer@test.com',
        name: 'María González',
        phone: '+54 11 5555-1234',
        role: 'volunteer',
        address: 'Belgrano 890, CABA',
        vehicleType: 'Auto',
        isActive: true,
        createdAt: new Date().toISOString(),
        coordinates: { lat: -34.5631, lng: -58.4544 }
      };
      setUser(demoUser);
      localStorage.setItem('user', JSON.stringify(demoUser));
      setIsLoading(false);
      return true;
    }
    
    setIsLoading(false);
    return false;
  };

  const register = async (userData: Partial<User> & { password: string }): Promise<boolean> => {
    setIsLoading(true);
    
    // Simular registro
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser: User = {
      id: Date.now().toString(),
      email: userData.email!,
      name: userData.name!,
      phone: userData.phone!,
      role: userData.role!,
      address: userData.address!,
      businessName: userData.businessName,
      cuit: userData.cuit,
      organizationType: userData.organizationType,
      capacity: userData.capacity,
      vehicleType: userData.vehicleType,
      isActive: true,
      createdAt: new Date().toISOString()
    };
    
    setUser(newUser);
    localStorage.setItem('user', JSON.stringify(newUser));
    setIsLoading(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateProfile = async (userData: Partial<User>): Promise<boolean> => {
    if (!user) return false;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const updatedUser = { ...user, ...userData };
    setUser(updatedUser);
    localStorage.setItem('user', JSON.stringify(updatedUser));
    setIsLoading(false);
    return true;
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      register,
      logout,
      updateProfile,
      isLoading
    }}>
      {children}
    </AuthContext.Provider>
  );
};