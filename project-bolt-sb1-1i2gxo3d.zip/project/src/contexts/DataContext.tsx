import React, { createContext, useContext, useState, useEffect } from 'react';
import { FoodItem, Donation, Stats, ConsolidatedLot, LogisticsProvider, LogisticsQuote, TaxCertificate } from '../types';

interface DataContextType {
  foodItems: FoodItem[];
  donations: Donation[];
  consolidatedLots: ConsolidatedLot[];
  logisticsProviders: LogisticsProvider[];
  taxCertificates: TaxCertificate[];
  stats: Stats;
  addFoodItem: (item: Omit<FoodItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateFoodItem: (id: string, updates: Partial<FoodItem>) => void;
  reserveFoodItem: (itemId: string, receiverId: string) => void;
  reserveConsolidatedLot: (lotId: string, receiverId: string, logisticsOption: 'beneficiary_covers' | 'shared_logistics') => void;
  joinSharedLogistics: (lotId: string, receiverId: string) => void;
  assignVolunteer: (donationId: string, volunteerId: string) => void;
  updateDonationStatus: (donationId: string, status: Donation['status']) => void;
  generateTaxCertificate: (donorId: string, donationIds: string[]) => void;
  getLogisticsQuotes: (lotId: string) => LogisticsQuote[];
  getFoodItemsByDonor: (donorId: string) => FoodItem[];
  getFoodItemsByReceiver: (receiverId: string) => FoodItem[];
  getDonationsByVolunteer: (volunteerId: string) => Donation[];
  getAvailableFoodItems: () => FoodItem[];
  getAvailableConsolidatedLots: () => ConsolidatedLot[];
  getConsolidatedLotsByZone: (zone: string) => ConsolidatedLot[];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

// Datos demo iniciales
const initialFoodItems: FoodItem[] = [
  {
    id: '1',
    donorId: '1',
    donorName: 'Supermercado Central',
    donorAddress: 'Av. Corrientes 1234, CABA',
    donorCoordinates: { lat: -34.6037, lng: -58.3816 },
    name: 'Pan integral',
    description: 'Pan integral artesanal, ideal para desayunos',
    quantity: 20,
    unit: 'unidades',
    category: 'bakery',
    expirationDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    collectionDeadline: new Date(Date.now() + 1.5 * 24 * 60 * 60 * 1000).toISOString(),
    availableHours: { start: '08:00', end: '18:00' },
    specialConditions: {
      refrigerationRequired: false,
      fragile: true,
      heavyItem: false,
      notes: 'Manejar con cuidado'
    },
    status: 'available',
    urgency: 'high',
    consolidatedLotId: 'lot1',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '2',
    donorId: '1',
    donorName: 'Supermercado Central',
    donorAddress: 'Av. Corrientes 1234, CABA',
    donorCoordinates: { lat: -34.6037, lng: -58.3816 },
    name: 'Verduras frescas',
    description: 'Mix de verduras frescas: lechuga, tomate, zanahoria',
    quantity: 15,
    unit: 'kg',
    category: 'vegetables',
    expirationDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    collectionDeadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    availableHours: { start: '06:00', end: '20:00' },
    specialConditions: {
      refrigerationRequired: true,
      fragile: false,
      heavyItem: false,
      notes: 'Mantener refrigerado'
    },
    status: 'available',
    urgency: 'medium',
    consolidatedLotId: 'lot1',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '3',
    donorId: '1',
    donorName: 'Supermercado Central',
    donorAddress: 'Av. Corrientes 1234, CABA',
    donorCoordinates: { lat: -34.6037, lng: -58.3816 },
    name: 'Lácteos variados',
    description: 'Leche, yogur y queso próximos a vencer',
    quantity: 25,
    unit: 'unidades',
    category: 'dairy',
    expirationDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
    collectionDeadline: new Date(Date.now() + 0.5 * 24 * 60 * 60 * 1000).toISOString(),
    availableHours: { start: '07:00', end: '19:00' },
    specialConditions: {
      refrigerationRequired: true,
      fragile: false,
      heavyItem: false,
      notes: 'Cadena de frío obligatoria'
    },
    status: 'reserved',
    urgency: 'high',
    reservedBy: '2',
    consolidatedLotId: 'lot1',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

const initialConsolidatedLots: ConsolidatedLot[] = [
  {
    id: 'lot1',
    zone: 'CABA Centro',
    totalWeight: 60,
    totalItems: 3,
    foodItems: ['1', '2', '3'],
    centerCoordinates: { lat: -34.6037, lng: -58.3816 },
    optimizedRoute: [
      {
        donorId: '1',
        address: 'Av. Corrientes 1234, CABA',
        coordinates: { lat: -34.6037, lng: -58.3816 },
        estimatedTime: 30,
        items: ['1', '2', '3']
      }
    ],
    status: 'ready',
    minimumWeight: 50,
    collectionDeadline: new Date(Date.now() + 0.5 * 24 * 60 * 60 * 1000).toISOString(),
    interestedBeneficiaries: ['2'],
    logisticsOption: 'beneficiary_covers',
    estimatedLogisticsCost: 2500,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

const initialLogisticsProviders: LogisticsProvider[] = [
  {
    id: 'lp1',
    name: 'TransAlimentos Express',
    vehicleTypes: ['Furgón refrigerado', 'Camión pequeño'],
    coverageZones: ['CABA Centro', 'CABA Norte', 'CABA Sur'],
    baseRate: 1500,
    ratePerKm: 50,
    ratePerKg: 10,
    rating: 4.8,
    isActive: true,
    specialServices: {
      refrigerated: true,
      fragileItems: true,
      heavyLifting: false
    }
  },
  {
    id: 'lp2',
    name: 'Logística Solidaria',
    vehicleTypes: ['Camión mediano', 'Furgón estándar'],
    coverageZones: ['CABA Centro', 'GBA Norte', 'GBA Sur'],
    baseRate: 1200,
    ratePerKm: 40,
    ratePerKg: 8,
    rating: 4.5,
    isActive: true,
    specialServices: {
      refrigerated: false,
      fragileItems: true,
      heavyLifting: true
    }
  }
];

const initialDonations: Donation[] = [
  {
    id: '1',
    foodItemId: '3',
    consolidatedLotId: 'lot1',
    donorId: '1',
    receiverId: '2',
    status: 'confirmed',
    logisticsType: 'beneficiary_covers',
    logisticsCost: 2500,
    trackingCode: 'TRK001',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

const initialTaxCertificates: TaxCertificate[] = [];

const initialStats: Stats = {
  totalKgRescued: 1250,
  totalDonations: 89,
  activeDonors: 15,
  activeReceivers: 8,
  activeVolunteers: 12,
  co2Saved: 875,
  beneficiariesReached: 450,
  monthlyStats: [
    { month: 'Enero', kgRescued: 180, donations: 12 },
    { month: 'Febrero', kgRescued: 220, donations: 15 },
    { month: 'Marzo', kgRescued: 195, donations: 14 },
    { month: 'Abril', kgRescued: 240, donations: 18 },
    { month: 'Mayo', kgRescued: 280, donations: 20 },
    { month: 'Junio', kgRescued: 135, donations: 10 }
  ]
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [foodItems, setFoodItems] = useState<FoodItem[]>(initialFoodItems);
  const [donations, setDonations] = useState<Donation[]>(initialDonations);
  const [consolidatedLots, setConsolidatedLots] = useState<ConsolidatedLot[]>(initialConsolidatedLots);
  const [logisticsProviders] = useState<LogisticsProvider[]>(initialLogisticsProviders);
  const [taxCertificates, setTaxCertificates] = useState<TaxCertificate[]>(initialTaxCertificates);
  const [stats, setStats] = useState<Stats>(initialStats);

  // Función para consolidar automáticamente los alimentos por zona
  const autoConsolidate = () => {
    const availableItems = foodItems.filter(item => 
      item.status === 'available' && !item.consolidatedLotId
    );

    // Agrupar por zona (simplificado por coordenadas cercanas)
    const zones: { [key: string]: FoodItem[] } = {};
    
    availableItems.forEach(item => {
      const zoneKey = `${Math.floor(item.donorCoordinates.lat * 100)}_${Math.floor(item.donorCoordinates.lng * 100)}`;
      if (!zones[zoneKey]) zones[zoneKey] = [];
      zones[zoneKey].push(item);
    });

    // Crear lotes consolidados para zonas con suficiente volumen
    Object.entries(zones).forEach(([zoneKey, items]) => {
      const totalWeight = items.reduce((sum, item) => sum + item.quantity, 0);
      
      if (totalWeight >= 50) { // Mínimo 50kg para consolidar
        const newLot: ConsolidatedLot = {
          id: `lot_${Date.now()}_${zoneKey}`,
          zone: `Zona ${zoneKey}`,
          totalWeight,
          totalItems: items.length,
          foodItems: items.map(item => item.id),
          centerCoordinates: {
            lat: items.reduce((sum, item) => sum + item.donorCoordinates.lat, 0) / items.length,
            lng: items.reduce((sum, item) => sum + item.donorCoordinates.lng, 0) / items.length
          },
          optimizedRoute: items.map(item => ({
            donorId: item.donorId,
            address: item.donorAddress,
            coordinates: item.donorCoordinates,
            estimatedTime: 30,
            items: [item.id]
          })),
          status: 'ready',
          minimumWeight: 50,
          collectionDeadline: new Date(Math.min(...items.map(item => new Date(item.collectionDeadline).getTime()))).toISOString(),
          interestedBeneficiaries: [],
          logisticsOption: 'beneficiary_covers',
          estimatedLogisticsCost: 1500 + (totalWeight * 10),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        setConsolidatedLots(prev => [...prev, newLot]);
        
        // Actualizar items para referenciar el lote
        items.forEach(item => {
          updateFoodItem(item.id, { consolidatedLotId: newLot.id });
        });
      }
    });
  };

  // Auto-consolidar cada vez que se agreguen nuevos items
  useEffect(() => {
    const timer = setTimeout(autoConsolidate, 2000);
    return () => clearTimeout(timer);
  }, [foodItems]);

  const calculateUrgency = (expirationDate: string): FoodItem['urgency'] => {
    const now = new Date();
    const expiry = new Date(expirationDate);
    const hoursUntilExpiry = (expiry.getTime() - now.getTime()) / (1000 * 60 * 60);
    
    if (hoursUntilExpiry <= 24) return 'high';
    if (hoursUntilExpiry <= 72) return 'medium';
    return 'low';
  };

  const addFoodItem = (item: Omit<FoodItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newItem: FoodItem = {
      ...item,
      id: Date.now().toString(),
      urgency: calculateUrgency(item.expirationDate),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setFoodItems(prev => [...prev, newItem]);
  };

  const updateFoodItem = (id: string, updates: Partial<FoodItem>) => {
    setFoodItems(prev => prev.map(item => 
      item.id === id 
        ? { ...item, ...updates, updatedAt: new Date().toISOString() }
        : item
    ));
  };

  const reserveFoodItem = (itemId: string, receiverId: string) => {
    const item = foodItems.find(f => f.id === itemId);
    if (!item || item.status !== 'available') return;

    updateFoodItem(itemId, { status: 'reserved', reservedBy: receiverId });
    
    const newDonation: Donation = {
      id: Date.now().toString(),
      foodItemId: itemId,
      donorId: item.donorId,
      receiverId,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setDonations(prev => [...prev, newDonation]);
  };

  const reserveConsolidatedLot = (lotId: string, receiverId: string, logisticsOption: 'beneficiary_covers' | 'shared_logistics') => {
    const lot = consolidatedLots.find(l => l.id === lotId);
    if (!lot || lot.status !== 'ready') return;

    // Actualizar el lote
    setConsolidatedLots(prev => prev.map(l => 
      l.id === lotId 
        ? { 
            ...l, 
            status: 'assigned', 
            assignedBeneficiary: receiverId,
            logisticsOption,
            updatedAt: new Date().toISOString() 
          }
        : l
    ));

    // Crear donación para el lote completo
    const newDonation: Donation = {
      id: Date.now().toString(),
      foodItemId: lot.foodItems[0], // Referencia al primer item del lote
      consolidatedLotId: lotId,
      donorId: lot.optimizedRoute[0].donorId,
      receiverId,
      status: 'confirmed',
      logisticsType: logisticsOption,
      logisticsCost: lot.estimatedLogisticsCost,
      trackingCode: `LOT${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setDonations(prev => [...prev, newDonation]);

    // Actualizar todos los items del lote
    lot.foodItems.forEach(itemId => {
      updateFoodItem(itemId, { status: 'reserved', reservedBy: receiverId });
    });
  };

  const joinSharedLogistics = (lotId: string, receiverId: string) => {
    setConsolidatedLots(prev => prev.map(lot => 
      lot.id === lotId 
        ? { 
            ...lot, 
            interestedBeneficiaries: [...lot.interestedBeneficiaries, receiverId],
            updatedAt: new Date().toISOString() 
          }
        : lot
    ));
  };

  const assignVolunteer = (donationId: string, volunteerId: string) => {
    setDonations(prev => prev.map(donation =>
      donation.id === donationId
        ? { ...donation, volunteerId, status: 'confirmed', updatedAt: new Date().toISOString() }
        : donation
    ));
  };

  const updateDonationStatus = (donationId: string, status: Donation['status']) => {
    setDonations(prev => prev.map(donation =>
      donation.id === donationId
        ? { ...donation, status, updatedAt: new Date().toISOString() }
        : donation
    ));

    if (status === 'delivered') {
      const donation = donations.find(d => d.id === donationId);
      if (donation) {
        updateFoodItem(donation.foodItemId, { status: 'delivered' });
      }
    }
  };

  const generateTaxCertificate = (donorId: string, donationIds: string[]) => {
    const relevantDonations = donations.filter(d => donationIds.includes(d.id));
    const totalValue = relevantDonations.length * 1000; // Valor estimado por donación
    const taxDeductionAmount = totalValue * 0.35; // 35% deducible

    const certificate: TaxCertificate = {
      id: `CERT${Date.now()}`,
      donorId,
      donationIds,
      totalValue,
      taxDeductionAmount,
      certificateNumber: `CERT-${new Date().getFullYear()}-${Date.now()}`,
      issueDate: new Date().toISOString(),
      fiscalYear: new Date().getFullYear().toString(),
      status: 'issued'
    };

    setTaxCertificates(prev => [...prev, certificate]);

    // Actualizar donaciones con referencia al certificado
    setDonations(prev => prev.map(donation =>
      donationIds.includes(donation.id)
        ? { ...donation, taxCertificateId: certificate.id, updatedAt: new Date().toISOString() }
        : donation
    ));
  };

  const getLogisticsQuotes = (lotId: string): LogisticsQuote[] => {
    const lot = consolidatedLots.find(l => l.id === lotId);
    if (!lot) return [];

    return logisticsProviders
      .filter(provider => provider.isActive)
      .map(provider => ({
        id: `quote_${provider.id}_${lotId}`,
        providerId: provider.id,
        consolidatedLotId: lotId,
        totalCost: provider.baseRate + (lot.totalWeight * provider.ratePerKg),
        estimatedTime: 120, // 2 horas estimadas
        vehicleType: provider.vehicleTypes[0],
        specialServices: Object.entries(provider.specialServices)
          .filter(([_, available]) => available)
          .map(([service, _]) => service),
        validUntil: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      }));
  };

  const getFoodItemsByDonor = (donorId: string) => {
    return foodItems.filter(item => item.donorId === donorId);
  };

  const getFoodItemsByReceiver = (receiverId: string) => {
    return foodItems.filter(item => item.reservedBy === receiverId);
  };

  const getDonationsByVolunteer = (volunteerId: string) => {
    return donations.filter(donation => donation.volunteerId === volunteerId);
  };

  const getAvailableFoodItems = () => {
    return foodItems.filter(item => item.status === 'available');
  };

  const getAvailableConsolidatedLots = () => {
    return consolidatedLots.filter(lot => lot.status === 'ready');
  };

  const getConsolidatedLotsByZone = (zone: string) => {
    return consolidatedLots.filter(lot => lot.zone === zone);
  };

  return (
    <DataContext.Provider value={{
      foodItems,
      donations,
      consolidatedLots,
      logisticsProviders,
      taxCertificates,
      stats,
      addFoodItem,
      updateFoodItem,
      reserveFoodItem,
      reserveConsolidatedLot,
      joinSharedLogistics,
      assignVolunteer,
      updateDonationStatus,
      generateTaxCertificate,
      getLogisticsQuotes,
      getFoodItemsByDonor,
      getFoodItemsByReceiver,
      getDonationsByVolunteer,
      getAvailableFoodItems,
      getAvailableConsolidatedLots,
      getConsolidatedLotsByZone
    }}>
      {children}
    </DataContext.Provider>
  );
};