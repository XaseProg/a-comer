export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: 'donor' | 'receiver' | 'volunteer' | 'admin';
  address: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  businessName?: string; // Para comercios
  cuit?: string; // Para comercios
  organizationType?: string; // Para receptores
  capacity?: number; // Para receptores
  vehicleType?: string; // Para voluntarios
  isActive: boolean;
  createdAt: string;
}

export interface FoodItem {
  id: string;
  donorId: string;
  donorName: string;
  donorAddress: string;
  donorCoordinates: {
    lat: number;
    lng: number;
  };
  name: string;
  description: string;
  quantity: number;
  unit: string;
  category: 'fruits' | 'vegetables' | 'dairy' | 'meat' | 'bakery' | 'canned' | 'other';
  expirationDate: string;
  collectionDeadline: string;
  availableHours: {
    start: string;
    end: string;
  };
  specialConditions: {
    refrigerationRequired: boolean;
    fragile: boolean;
    heavyItem: boolean;
    notes?: string;
  };
  imageUrl?: string;
  status: 'available' | 'reserved' | 'in_transit' | 'delivered' | 'expired';
  urgency: 'low' | 'medium' | 'high';
  reservedBy?: string;
  assignedVolunteer?: string;
  consolidatedLotId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ConsolidatedLot {
  id: string;
  zone: string;
  totalWeight: number;
  totalItems: number;
  foodItems: string[];
  centerCoordinates: {
    lat: number;
    lng: number;
  };
  optimizedRoute: {
    donorId: string;
    address: string;
    coordinates: { lat: number; lng: number };
    estimatedTime: number;
    items: string[];
  }[];
  status: 'forming' | 'ready' | 'assigned' | 'in_collection' | 'completed';
  minimumWeight: number;
  collectionDeadline: string;
  interestedBeneficiaries: string[];
  assignedBeneficiary?: string;
  logisticsOption: 'beneficiary_covers' | 'shared_logistics';
  estimatedLogisticsCost: number;
  createdAt: string;
  updatedAt: string;
}

export interface LogisticsProvider {
  id: string;
  name: string;
  vehicleTypes: string[];
  coverageZones: string[];
  baseRate: number;
  ratePerKm: number;
  ratePerKg: number;
  rating: number;
  isActive: boolean;
  specialServices: {
    refrigerated: boolean;
    fragileItems: boolean;
    heavyLifting: boolean;
  };
}

export interface LogisticsQuote {
  id: string;
  providerId: string;
  consolidatedLotId: string;
  totalCost: number;
  estimatedTime: number;
  vehicleType: string;
  specialServices: string[];
  validUntil: string;
}

export interface TaxCertificate {
  id: string;
  donorId: string;
  donationIds: string[];
  totalValue: number;
  taxDeductionAmount: number;
  certificateNumber: string;
  issueDate: string;
  fiscalYear: string;
  status: 'pending' | 'issued' | 'sent';
  pdfUrl?: string;
}

export interface Donation {
  id: string;
  foodItemId: string;
  consolidatedLotId?: string;
  donorId: string;
  receiverId: string;
  volunteerId?: string;
  logisticsProviderId?: string;
  status: 'pending' | 'confirmed' | 'in_transit' | 'delivered' | 'cancelled';
  logisticsType: 'beneficiary_covers' | 'shared_logistics' | 'volunteer';
  logisticsCost?: number;
  sharedCostParticipants?: {
    beneficiaryId: string;
    sharePercentage: number;
    amountToPay: number;
  }[];
  scheduledPickup?: string;
  scheduledDelivery?: string;
  actualPickup?: string;
  actualDelivery?: string;
  trackingCode?: string;
  gpsTracking?: {
    lat: number;
    lng: number;
    timestamp: string;
  }[];
  notes?: string;
  rating?: number;
  feedback?: string;
  taxCertificateId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Route {
  id: string;
  volunteerId: string;
  donations: string[];
  optimizedOrder: {
    donationId: string;
    address: string;
    coordinates: {
      lat: number;
      lng: number;
    };
    type: 'pickup' | 'delivery';
  }[];
  totalDistance: number;
  estimatedTime: number;
  status: 'planned' | 'in_progress' | 'completed';
  createdAt: string;
}

export interface Stats {
  totalKgRescued: number;
  totalDonations: number;
  activeDonors: number;
  activeReceivers: number;
  activeVolunteers: number;
  co2Saved: number; // kg de CO2
  beneficiariesReached: number;
  monthlyStats: {
    month: string;
    kgRescued: number;
    donations: number;
  }[];
}